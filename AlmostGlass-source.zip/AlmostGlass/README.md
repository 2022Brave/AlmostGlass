# Almost Glass — native Android starter

A native Kotlin + Jetpack Compose entertainment catalogue starter with a translucent Liquid Glass-inspired UI.

## Implemented in this first build
- Home / trending, Movies, Series, Anime, Search and Watch History navigation
- Live TMDB catalogue queries after the user supplies their own API key
- Title details and links to TMDB catalogue pages
- Device-local watch history for the current app session
- Live TV channel URL list entry (URLs are not bundled); opening a stream delegates to the Android handler/browser
- Settings for a personal TMDB API key
- GitHub Actions workflow to build a debug APK in the cloud

## Build APK without a computer
1. Create a GitHub repository and upload these project files.
2. Open the repository's **Actions** tab and run **Build Android APK** (or push to `main`).
3. Open the completed workflow run, download the `AlmostGlass-debug-apk` artifact, unzip it, and install `app-debug.apk` on your phone. You may need to allow installation from the browser/files app.

## TMDB setup
Request a personal API key from https://www.themoviedb.org/settings/api and enter it in the app's Settings. For non-commercial use, TMDB says API usage is free with attribution; check its current terms before distribution. This app includes the required attribution notice in Settings.

## Legal streaming
TMDB provides catalogue metadata and artwork, not a licence to stream the titles. No unverified streams are bundled. Add only official/public-domain/otherwise licensed channel URLs. The current Live TV list is in-memory and the stream opens via Android's registered handler; integrated in-app HLS playback and persistent channel storage are planned for a later iteration.

## Package details
- App label: Almost Glass
- Application ID: `com.almostglass.app`
- Min Android: 8.0 (API 26)
- Kotlin, Jetpack Compose, Material 3, Coil
