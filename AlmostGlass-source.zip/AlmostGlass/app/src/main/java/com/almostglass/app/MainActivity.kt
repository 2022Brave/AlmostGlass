package com.almostglass.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Ink = Color(0xFF090B12)
private val Panel = Color(0xCC191D2B)
private val Glass = Color(0x35FFFFFF)
private val Violet = Color(0xFFB59AFF)
private val Mint = Color(0xFF9EF5D0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AlmostGlassApp(this) }
    }
}

data class MediaItem(val id: Int, val title: String, val overview: String, val poster: String?, val year: String, val kind: String, val rating: String = "")

private fun prefs(ctx: Context) = ctx.getSharedPreferences("almost_glass", Context.MODE_PRIVATE)

private suspend fun tmdb(path: String, key: String): List<MediaItem> = withContext(Dispatchers.IO) {
    if (key.isBlank()) return@withContext emptyList()
    val url = URL("https://api.themoviedb.org/3$path" + if (path.contains("?")) "&api_key=$key" else "?api_key=$key")
    val connection = (url.openConnection() as HttpURLConnection).apply { connectTimeout = 10000; readTimeout = 10000; requestMethod = "GET" }
    try {
        val body = connection.inputStream.bufferedReader().use { it.readText() }
        val results = JSONObject(body).optJSONArray("results") ?: return@withContext emptyList()
        (0 until results.length()).mapNotNull { i ->
            val o = results.optJSONObject(i) ?: return@mapNotNull null
            val type = if (o.has("title")) "Movie" else "Series"
            val name = o.optString("title", o.optString("name", "Untitled"))
            val date = o.optString("release_date", o.optString("first_air_date", ""))
            MediaItem(o.optInt("id"), name, o.optString("overview", "No synopsis available."), o.optString("poster_path").takeIf { it.isNotBlank() && it != "null" }?.let { "https://image.tmdb.org/t/p/w500$it" }, date.take(4), type, o.optDouble("vote_average", 0.0).let { if (it > 0) "%.1f".format(it) else "" })
        }
    } finally { connection.disconnect() }
}

@Composable
fun AlmostGlassApp(ctx: Context) {
    val savedKey = remember { mutableStateOf(prefs(ctx).getString("tmdb_key", "") ?: "") }
    var apiKey by savedKey
    var page by remember { mutableStateOf("Home") }
    var search by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<MediaItem?>(null) }
    var items by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    val history = remember { mutableStateListOf<MediaItem>() }
    val liveStreams = remember { mutableStateListOf<Pair<String, String>>() }
    var channelName by remember { mutableStateOf("") }
    var streamUrl by remember { mutableStateOf("") }

    LaunchedEffect(page, apiKey, search, refresh) {
        if (page in listOf("Home", "Movies", "Series", "Anime", "Search") && apiKey.isNotBlank()) {
            loading = true; error = ""
            try {
                val path = when (page) {
                    "Movies" -> "/movie/popular?language=en-US&page=1"
                    "Series" -> "/tv/popular?language=en-US&page=1"
                    "Anime" -> "/discover/tv?with_genres=16&with_original_language=ja&sort_by=popularity.desc&page=1"
                    "Search" -> if (search.isNotBlank()) "/search/multi?query=${Uri.encode(search)}&include_adult=false&language=en-US&page=1" else "/trending/all/week?language=en-US"
                    else -> "/trending/all/week?language=en-US"
                }
                items = tmdb(path, apiKey)
            } catch (e: Exception) { error = "Couldn't load catalogue. Check your connection and TMDB key."; items = emptyList() }
            loading = false
        } else if (page == "History") items = history.toList()
        else if (page in listOf("Live TV", "Settings")) items = emptyList()
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Violet, secondary = Mint, background = Ink, surface = Panel)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF19152D), Ink, Color(0xFF071B20))))) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(15.dp)).background(Brush.linearGradient(listOf(Violet, Color(0xFF6650A4)))), contentAlignment = Alignment.Center) { Icon(Icons.Default.PlayArrow, null, tint = Ink, modifier = Modifier.size(27.dp)) }
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f)) { Text("ALMOST", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp); Text("GLASS  ·  ENTERTAINMENT", color = Violet, fontSize = 9.sp, letterSpacing = 1.6.sp) }
                    IconButton(onClick = { page = "Search" }) { Icon(Icons.Default.Search, "Search", tint = Color.White) }
                }
                if (page == "Search") {
                    GlassInput(search, { search = it }, "Search movies, series, anime…", Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 5.dp))
                }
                AnimatedContent(targetState = page, label = "page", modifier = Modifier.weight(1f)) { target ->
                    when (target) {
                        "Settings" -> SettingsScreen(apiKey, { apiKey = it; prefs(ctx).edit().putString("tmdb_key", it).apply(); refresh++ })
                        "Live TV" -> LiveScreen(liveStreams, channelName, { channelName = it }, streamUrl, { streamUrl = it }, { name, url ->
                            if (name.isNotBlank() && (url.startsWith("https://") || url.startsWith("http://"))) { liveStreams.add(name to url); channelName = ""; streamUrl = "" }
                        }, ctx)
                        "Detail" -> selected?.let { DetailScreen(it, { if (history.none { h -> h.id == it.id && h.kind == it.kind }) history.add(0, it); page = "History" }, ctx) }
                        else -> MainCatalog(page, items, loading, error, apiKey, { page = "Settings" }, { selected = it; page = "Detail" }, { refresh++ })
                    }
                }
                NavigationBar(containerColor = Color(0xDD0E101A), contentColor = Color.White) {
                    listOf("Home" to Icons.Default.Home, "Movies" to Icons.Default.Movie, "Series" to Icons.Default.Tv, "Anime" to Icons.Default.Animation, "Live TV" to Icons.Default.LiveTv, "History" to Icons.Default.History).forEach { (label, icon) ->
                        NavigationBarItem(selected = page == label, onClick = { page = label }, icon = { Icon(icon, contentDescription = label) }, label = { Text(label, fontSize = 9.sp, maxLines = 1) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Violet, selectedTextColor = Violet, indicatorColor = Color(0x443D315D), unselectedIconColor = Color.LightGray, unselectedTextColor = Color.LightGray))
                    }
                }
            }
        }
    }
}

@Composable
private fun MainCatalog(page: String, items: List<MediaItem>, loading: Boolean, error: String, apiKey: String, openSettings: () -> Unit, openDetail: (MediaItem) -> Unit, refresh: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Column(Modifier.padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(6.dp))
                GlassPanel(Modifier.fillMaxWidth().height(165.dp)) {
                    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xAA7758B7), Color(0x88334C71), Color(0x3311A68D)))).padding(18.dp)) {
                        Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(.78f)) {
                            Text("YOUR NEXT OBSESSION", color = Mint, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp)); Text("Stories worth\nstaying up for.", color = Color.White, fontSize = 27.sp, lineHeight = 30.sp, fontWeight = FontWeight.ExtraBold)
                            Spacer(Modifier.height(8.dp)); Text("Movies · Series · Anime · Live", color = Color.White.copy(alpha = .75f), fontSize = 11.sp)
                        }
                        Icon(Icons.Default.AutoAwesome, null, tint = Violet.copy(alpha = .8f), modifier = Modifier.align(Alignment.TopEnd).size(31.dp))
                    }
                }
                Spacer(Modifier.height(17.dp))
                Row(verticalAlignment = Alignment.CenterVertically) { Text(if (page == "Home") "Trending this week" else page, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Text("LIVE UI PREVIEW", color = Mint, fontSize = 9.sp, letterSpacing = 1.sp) }
                if (apiKey.isBlank()) {
                    Spacer(Modifier.height(12.dp)); GlassPanel(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) { Text("Connect your catalogue", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp); Spacer(Modifier.height(5.dp)); Text("Add your free personal-use TMDB API key in Settings to load real movie and series metadata.", color = Color.LightGray, fontSize = 12.sp, lineHeight = 18.sp); Spacer(Modifier.height(12.dp)); Button(onClick = openSettings, colors = ButtonDefaults.buttonColors(containerColor = Violet, contentColor = Ink)) { Text("Set up TMDB") } }
                    }
                }
                if (error.isNotBlank()) Text(error, color = Color(0xFFFFB6B6), modifier = Modifier.padding(top = 10.dp))
            }
        }
        if (loading) item { Box(Modifier.fillMaxWidth().padding(30.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Violet) } }
        if (items.isNotEmpty()) {
            item { Text("  PICKS FOR YOU", color = Violet, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold) }
            items(items) { media -> MediaRow(media, { openDetail(media) }) }
        }
        if (!loading && apiKey.isNotBlank() && items.isEmpty() && error.isBlank()) item { Text("Nothing here yet. Pull the refresh button below.", color = Color.LightGray, modifier = Modifier.padding(20.dp)) }
        item { OutlinedButton(onClick = refresh, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Violet)) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(8.dp)); Text("Refresh catalogue") } }
        item { Text("Metadata and artwork by TMDB. Not endorsed or certified by TMDB.", color = Color.Gray, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 18.dp)) }
    }
}

@Composable
private fun MediaRow(item: MediaItem, onClick: () -> Unit) {
    GlassPanel(Modifier.fillMaxWidth().padding(horizontal = 18.dp).clickable(onClick = onClick)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(model = item.poster, contentDescription = item.title, modifier = Modifier.width(78.dp).height(108.dp).clip(RoundedCornerShape(13.dp)).background(Color(0xFF292D3D)))
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(5.dp)); Text(listOf(item.kind, item.year, if (item.rating.isNotBlank()) "★ ${item.rating}" else "").filter { it.isNotBlank() }.joinToString("  ·  "), color = Mint, fontSize = 10.sp)
                Spacer(Modifier.height(7.dp)); Text(item.overview.ifBlank { "Discover more about this title." }, color = Color.LightGray, fontSize = 11.sp, maxLines = 3, overflow = TextOverflow.Ellipsis, lineHeight = 15.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Violet)
        }
    }
}

@Composable
private fun DetailScreen(item: MediaItem, history: () -> Unit, ctx: Context) {
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { GlassPanel(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) {
            AsyncImage(model = item.poster, contentDescription = item.title, modifier = Modifier.fillMaxWidth().height(300.dp).clip(RoundedCornerShape(18.dp)).background(Panel))
            Spacer(Modifier.height(14.dp)); Text(item.title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold); Text("${item.kind}  ·  ${item.year}  ·  ${if (item.rating.isBlank()) "Not rated" else "★ ${item.rating}"}", color = Mint, fontSize = 12.sp); Spacer(Modifier.height(12.dp)); Text(item.overview, color = Color.LightGray, fontSize = 14.sp, lineHeight = 21.sp); Spacer(Modifier.height(18.dp)); Button(onClick = history, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Violet, contentColor = Ink)) { Icon(Icons.Default.BookmarkAdd, null); Spacer(Modifier.width(8.dp)); Text("Add to watch history") }; Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.themoviedb.org/${if (item.kind == "Movie") "movie" else "tv"}/${item.id}"))) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Violet)) { Text("View official catalogue details") }
        } } }
    }
}

@Composable
private fun SettingsScreen(apiKey: String, onSave: (String) -> Unit) {
    var key by remember(apiKey) { mutableStateOf(apiKey) }
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        GlassPanel(Modifier.fillMaxWidth()) { Column(Modifier.padding(17.dp)) {
            Text("Catalogue source", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(6.dp)); Text("Use your own TMDB API key to fetch live movie, TV and anime metadata. The key stays on this device.", color = Color.LightGray, fontSize = 12.sp, lineHeight = 18.sp); Spacer(Modifier.height(12.dp)); GlassInput(key, { key = it }, "TMDB API key", Modifier.fillMaxWidth()); Spacer(Modifier.height(12.dp)); Button(onClick = { onSave(key.trim()) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Violet, contentColor = Ink)) { Text("Save API key") }; Spacer(Modifier.height(14.dp)); Text("Get a key: developer.themoviedb.org", color = Mint, fontSize = 12.sp, modifier = Modifier.clickable { }); Spacer(Modifier.height(12.dp)); Text("Attribution: This product uses TMDB and the TMDB APIs but is not endorsed, certified, or otherwise approved by TMDB.", color = Color.Gray, fontSize = 10.sp, lineHeight = 15.sp)
        } }
        GlassPanel(Modifier.fillMaxWidth()) { Column(Modifier.padding(17.dp)) { Text("Streaming policy", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text("This build does not scrape third-party streams. Live TV accepts only stream URLs you have permission to use. Catalogue metadata is not a playback licence.", color = Color.LightGray, fontSize = 12.sp, lineHeight = 18.sp) } }
    }
}

@Composable
private fun LiveScreen(streams: List<Pair<String, String>>, name: String, setName: (String) -> Unit, url: String, setUrl: (String) -> Unit, add: (String, String) -> Unit, ctx: Context) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Live TV", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold); Text("Add official or otherwise licensed channel URLs. Only add streams you are authorized to access.", color = Color.LightGray, fontSize = 12.sp, lineHeight = 18.sp) }
        item { GlassPanel(Modifier.fillMaxWidth()) { Column(Modifier.padding(15.dp)) { GlassInput(name, setName, "Channel name", Modifier.fillMaxWidth()); Spacer(Modifier.height(9.dp)); GlassInput(url, setUrl, "HTTPS stream URL (HLS .m3u8, etc.)", Modifier.fillMaxWidth()); Spacer(Modifier.height(10.dp)); Button(onClick = { add(name.trim(), url.trim()) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Violet, contentColor = Ink)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add channel") } } } }
        if (streams.isEmpty()) item { GlassPanel(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Icon(Icons.Default.LiveTv, null, tint = Mint, modifier = Modifier.size(30.dp)); Spacer(Modifier.height(8.dp)); Text("Your channel list starts here", color = Color.White, fontWeight = FontWeight.Bold); Text("No third-party channels are preloaded. This avoids bundling unverified or unauthorized streams.", color = Color.LightGray, fontSize = 12.sp) } } }
        items(streams) { stream -> GlassPanel(Modifier.fillMaxWidth()) { Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.PlayCircle, null, tint = Mint, modifier = Modifier.size(34.dp)); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(stream.first, color = Color.White, fontWeight = FontWeight.Bold); Text(stream.second, color = Color.Gray, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }; IconButton(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(stream.second))) }) { Icon(Icons.Default.OpenInNew, "Open stream", tint = Violet) } } } }
    }
}

@Composable
private fun GlassPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0x44FFFFFF), Color(0x101A2035), Color(0x222A2144)))).border(1.dp, Brush.linearGradient(listOf(Color(0x55FFFFFF), Color(0x18B59AFF))), RoundedCornerShape(22.dp)), content = content)
}

@Composable
private fun GlassInput(value: String, onChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier) {
    Row(modifier.clip(RoundedCornerShape(14.dp)).background(Color(0x33FFFFFF)).border(1.dp, Glass, RoundedCornerShape(14.dp)).padding(horizontal = 13.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        BasicTextField(value = value, onValueChange = onChange, modifier = Modifier.weight(1f), singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 13.sp), decorationBox = { inner -> Box { if (value.isEmpty()) Text(placeholder, color = Color.Gray, fontSize = 13.sp); inner() } })
    }
}
